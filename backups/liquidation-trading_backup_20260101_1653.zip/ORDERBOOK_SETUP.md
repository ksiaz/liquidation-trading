# Orderbook Storage - Quick Setup Guide

## ✅ Integration Complete

Orderbook storage has been integrated into your dashboard server. It will automatically start when you run the dashboard.

---

## Setup Steps

### 1. Create Database Tables (One-Time)

Run this command **once** to create the orderbook tables:

```bash
psql -U postgres -d liquidation_trading -f database_orderbook_schema.sql
```

**Note**: Replace `postgres` with your PostgreSQL username if different (check your `.env` file).

---

### 2. Start Dashboard (As Normal)

Just run your dashboard as usual:

```bash
python dashboard_server.py
```

Or the desktop app:

```bash
python desktop_app.py
```

The orderbook storage will start automatically in the background.

---

## Verify It's Working

### Check Logs

You should see this in the console:

```
INFO - Orderbook storage started - capturing 1s snapshots to database
INFO - Starting orderbook storage manager...
INFO - Symbols: BTCUSDT, ETHUSDT, SOLUSDT
INFO - Order book WebSocket connected
```

### Check Database

After a few minutes, verify data is being stored:

```sql
-- Connect to database
psql -U postgres -d liquidation_trading

-- Check snapshot count
SELECT 
    symbol,
    COUNT(*) as snapshots,
    MIN(timestamp) as first_snapshot,
    MAX(timestamp) as last_snapshot
FROM orderbook_snapshots
GROUP BY symbol;

-- Should show ~60 snapshots per minute per symbol
```

### View Recent Data

```sql
-- Get latest orderbook for BTC
SELECT * FROM latest_orderbook WHERE symbol = 'BTCUSDT';

-- Get last 10 snapshots
SELECT 
    timestamp,
    best_bid,
    best_ask,
    spread_bps
FROM orderbook_snapshots
WHERE symbol = 'BTCUSDT'
ORDER BY timestamp DESC
LIMIT 10;
```

---

## Storage Monitoring

### Check Storage Size

```sql
SELECT 
    pg_size_pretty(pg_total_relation_size('orderbook_snapshots')) as snapshots_size,
    pg_size_pretty(pg_total_relation_size('orderbook_metrics')) as metrics_size;
```

### Expected Growth

| Time Period | Storage (3 symbols) |
|-------------|---------------------|
| 1 hour | 7.5 MB |
| 1 day | 180 MB |
| 1 week | 1.26 GB |
| 1 month | 5.4 GB |

---

## What Gets Stored

### Every Second (Per Symbol)

- **Full 20-level orderbook**
  - 20 bid levels: [price, quantity]
  - 20 ask levels: [price, quantity]
  
- **Pre-calculated metrics**
  - Depth at 5, 10, 20 levels
  - Orderbook imbalance
  - Large wall detection
  - Spread and mid-price

---

## Troubleshooting

### "Table does not exist" Error

Run the schema creation:
```bash
psql -U postgres -d liquidation_trading -f database_orderbook_schema.sql
```

### "Orderbook storage not available" Warning

Check that `orderbook_storage.py` exists in your directory:
```bash
ls orderbook_storage.py
```

### No Data Being Stored

Check if orderbook stream is connected:
```python
# In Python console
from orderbook_stream import BinanceOrderBookStream
stream = BinanceOrderBookStream(['BTCUSDT'], depth=20)
stream.start()
# Should connect without errors
```

### High CPU/Memory Usage

The orderbook storage is lightweight, but if you experience issues:

1. **Reduce storage frequency** (edit `orderbook_storage.py`):
   ```python
   self.storage_interval = 2.0  # Store every 2 seconds instead of 1
   ```

2. **Reduce buffer size**:
   ```python
   self.buffer_size = 5  # Flush every 5 snapshots instead of 10
   ```

---

## Cleanup Old Data

The schema includes an automatic cleanup function. Run manually:

```sql
-- Delete data older than 30 days
SELECT cleanup_old_orderbook_data();
```

Or set up automatic cleanup (requires `pg_cron` extension):

```sql
-- Run cleanup every Sunday at 2 AM
SELECT cron.schedule('cleanup-orderbook', '0 2 * * 0', 'SELECT cleanup_old_orderbook_data()');
```

---

## Next Steps

Once data is collecting:

1. **Let it run for 24 hours** to gather initial data
2. **Implement advanced strategies** using the stored orderbook data
3. **Query historical orderbook** for backtesting
4. **Build analytics** on depth, imbalance, and wall detection

See `ORDERBOOK_STORAGE.md` for detailed usage examples and analytics queries.

---

## Files

- `database_orderbook_schema.sql` - Database schema
- `orderbook_storage.py` - Storage manager (auto-starts with dashboard)
- `ORDERBOOK_STORAGE.md` - Detailed documentation
- `ORDERBOOK_SETUP.md` - This quick setup guide

**Status**: ✅ Integrated and ready to use!
