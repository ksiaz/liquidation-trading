# Liquidation Trading System

Real-time liquidation monitoring and analysis system for Binance Futures (BTC, ETH, SOL).

## Features

- 📡 Live WebSocket connection to Binance liquidation stream
- 💾 PostgreSQL database storage for fast queries
- 🤖 **Data-Driven Signal Generator** - Liquidity Drain Detector with per-symbol optimization
- 📈 Real-time orderbook analytics and 20-level depth tracking
- 🎯 Configurable filters for significant liquidation events
- 📊 Real-time statistics and monitoring dashboard
- 🔄 Automatic reconnection and error handling

## Quick Start

### 1. Install PostgreSQL

See [DATABASE_SETUP.md](DATABASE_SETUP.md) for detailed instructions.

**Quick option (Docker)**:
```bash
docker run --name liquidation-postgres \
  -e POSTGRES_PASSWORD=your_password \
  -e POSTGRES_DB=liquidation_trading \
  -p 5432:5432 \
  -d postgres:14
```

### 2. Configure Environment

```bash
# Copy template
cp .env.example .env

# Edit .env with your database credentials
# DB_HOST=localhost
# DB_PORT=5432
# DB_NAME=liquidation_trading
# DB_USER=postgres
# DB_PASSWORD=your_password_here
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

### 4. Setup Database

```bash
python database.py
```

You should see:
```
✓ Connected to database
✓ Tables created
✅ Database setup complete!
```

### 5. Run the Monitor

```bash
python monitor.py
```

This will:
- Connect to Binance WebSocket stream
- Monitor BTC, ETH, and SOL liquidations
- Save all data to PostgreSQL database
- Display significant liquidation events in real-time

### 6. Stop the Monitor

Press `Ctrl+C` to gracefully shutdown and save all data.

## Configuration

Edit `config.py` to customize:

- **Symbols**: Which trading pairs to monitor
- **Thresholds**: Minimum USD value for "significant" liquidations
- **Buffer Settings**: How often to flush data to database

## Project Structure

```
liquidation-trading/
├── dashboard_server.py          # Web dashboard (Flask)
├── monitor.py                   # Liquidation stream monitor
├── signal_generator.py          # NEW: Signal generation wrapper
├── liquidity_drain_detector.py  # NEW: Data-driven detector
├── early_reversal_detector.py   # OLD: Legacy detector
├── orderbook_storage.py         # 20-level orderbook capture
├── liquidation_stream.py        # WebSocket client
├── database.py                  # Database schema & queries
├── config.py                    # Configuration
└── README.md                    # This file
```

## Database Schema

### Core Tables

1. **liquidations**: Main data table with all liquidation events
   - Stores: Binance, dYdX, Hyperliquid liquidations
   - ~100-500 events/day per symbol
   - Indexed by symbol, timestamp, value

2. **liquidation_stats**: Daily aggregated statistics
   - Daily summaries per symbol/side
   - Used for dashboard metrics

3. **monitor_sessions**: Session tracking and metadata
   - Tracks each monitoring session
   - Uptime, event counts, status

### Orderbook Storage Tables (Optional)

4. **orderbook_snapshots**: Full 20-level orderbook data
   - Stores: Complete bid/ask depth (20 levels) in JSONB
   - Frequency: 1-second snapshots
   - Storage: ~5.4 GB/month for 3 symbols
   - **See [ORDERBOOK_STORAGE.md](ORDERBOOK_STORAGE.md) for details**

5. **orderbook_metrics**: Pre-calculated orderbook analytics
   - Depth at 5/10/20 levels
   - Orderbook imbalance
   - Wall detection
   - Derived from snapshots

### Legacy Tables

6. **orderbook_depth**: Liquidity analysis (old format)
7. **orderbook_walls**: Large order detection (old format)

> **Note**: To enable full orderbook storage, see [ORDERBOOK_SETUP.md](ORDERBOOK_SETUP.md)

### Querying Data

```python
from database import DatabaseManager

db = DatabaseManager()

# Get statistics
stats = db.get_stats(symbol='BTCUSDT')
print(f"Total: ${stats['total_value']:,.2f}")

# Get recent events
recent = db.get_recent_liquidations(limit=10)
for event in recent:
    print(f"{event['symbol']} ${event['value_usd']:,.2f}")

db.close()
```

## Signal Generator (NEW)

### LiquidityDrainDetector

Data-driven signal generator based on empirical analysis of 56K+ orderbook snapshots.

**Key Discovery:** Volume depletion (not imbalance) predicts reversals.

**Performance (Backtested on 8h data):**
- ETH: 58.8% win rate, +2.09% per 8h
- BTC: 50.8% win rate, +0.81% per 8h
- SOL: 47.6% win rate, +0.39% per 8h
- **Combined: 52.4% win rate, +3.29% per 8h**

**How it works:**
1. Monitors 20-level orderbook depth in real-time
2. Detects liquidity drain patterns (depth < 96% avg, declining slope)
3. Analyzes tick divergence (fake pumps vs capitulation)
4. Confirms with price context (mean reversion)
5. Generates high-confidence signals only

**Per-Symbol Configuration:**
- Uses optimized thresholds for each symbol (BTC/ETH/SOL)
- Automatic integration via `signal_generator.py`
- Already deployed in dashboard

### Usage

```python
from liquidity_drain_detector import LiquidityDrainDetector

# Auto-loads optimized config for symbol
detector = LiquidityDrainDetector(symbol='ETHUSDT')

# Process orderbook updates
signal = detector.update(orderbook_data)

if signal:
    print(f"{signal['direction']} @ ${signal['entry_price']}")
    print(f"Confidence: {signal['confidence']}%")
```

## Next Steps

1. **Run Dashboard**: `python dashboard_server.py` - NEW detector active
2. **Monitor Performance**: Track live signal quality and win rates
3. **Paper Trade**: Validate 48-72h before live deployment
4. **Optimize**: Adjust per-symbol thresholds if needed

## Troubleshooting

**WebSocket disconnects frequently:**
- This is normal. The system auto-reconnects.
- Binance connections expire after 24 hours.

**Database connection errors:**
- Verify PostgreSQL is running
- Check credentials in `.env` file
- See [DATABASE_SETUP.md](DATABASE_SETUP.md) for help

**Missing liquidations:**
- Binance only sends 1 liquidation per symbol per second (snapshot behavior)
- This is a Binance limitation, not a bug

## License

MIT
