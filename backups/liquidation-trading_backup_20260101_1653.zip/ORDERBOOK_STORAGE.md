# Orderbook Storage System

## Overview

Full 20-level orderbook storage system for Binance Futures (BTC, ETH, SOL).

**Storage Rate**: 1-second snapshots  
**Expected Storage**: ~5.4 GB/month for 3 symbols  
**Data Retention**: 30 days (configurable)

---

## Quick Start

### 1. Create Database Schema

```bash
# Run SQL schema
psql -U your_user -d liquidation_trading -f database_orderbook_schema.sql
```

This creates:
- `orderbook_snapshots` - Aggregated orderbook metrics (depth, imbalance, spread)
- Indexes for fast queries
- Views for easy access

### 2. Start Orderbook Storage

```bash
# Run standalone
python orderbook_storage.py
```

Or integrate into your existing system:

```python
from orderbook_storage import OrderbookStorageManager
from database import DatabaseManager

db = DatabaseManager()
symbols = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT']

storage = OrderbookStorageManager(symbols, db)
storage.start()
```

---

## Database Schema

### `orderbook_snapshots` Table

Stores aggregated orderbook snapshots (does **NOT** store full JSONB arrays):

| Column | Type | Description |
|--------|------|-------------|
| id | BIGSERIAL | Primary key |
| symbol | VARCHAR(20) | Trading pair |
| timestamp | TIMESTAMP | Snapshot time |
| best_bid | DECIMAL | Best bid price |
| best_ask | DECIMAL | Best ask price |
| spread_pct | DECIMAL | Spread percentage |
| spread | DECIMAL | Spread (raw value) |
| bid_volume_10 | DECIMAL | Total bid volume (top 10 levels) |
| ask_volume_10 | DECIMAL | Total ask volume (top 10 levels) |
| bid_value_10 | DECIMAL | Total bid value in USD (top 10 levels) |
| ask_value_10 | DECIMAL | Total ask value in USD (top 10 levels) |
| **imbalance** | **DECIMAL** | **Orderbook Skew (-1 to +1)** |

**Indexes**:
- `idx_ob_symbol_time` - Fast symbol + time queries
- `idx_ob_recent` - Optimized for last 7 days

---

## Usage Examples

### Query Orderbook Skew (Imbalance)

```sql
-- Get skew for ETH V-Pattern detection
SELECT 
    timestamp,
    imbalance,
    best_bid, 
    best_ask
FROM orderbook_snapshots 
WHERE symbol = 'ETHUSDT'
ORDER BY timestamp DESC
LIMIT 10;
```

### Analyze Depth Balance

```sql
-- Compare bid vs ask value
SELECT 
    timestamp,
    bid_value_10,
    ask_value_10,
    (bid_value_10 - ask_value_10) as net_liquidity
FROM orderbook_snapshots
WHERE symbol = 'BTCUSDT'
  AND timestamp > NOW() - INTERVAL '1 hour'
ORDER BY timestamp;
```

---

## Storage Estimates

| Timeframe | Storage (3 symbols) |
|-----------|---------------------|
| 1 day | 180 MB |
| 1 week | 1.26 GB |
| 1 month | 5.4 GB |
| 3 months | 16.2 GB |
| 6 months | 32.4 GB |
| 1 year | 64.8 GB |

**Recommendation**: Keep 30-90 days of data, archive older data to S3/cold storage.

---

## Recent Fixes & Troubleshooting

### Schema Mismatch Fix (2025-12-31)

**Problem**: 
The `orderbook_storage.py` script was originally written to insert into `bids` and `asks` JSONB columns, but the actual database table used aggregated columns (`imbalance`, `spread_pct`, etc.). This resulted in silent failures where no data was being stored.

**Resolution**:
Updated `orderbook_storage.py` to match the actual database schema:
1. Removed attempts to insert into non-existent JSONB columns
2. Added calculation of metrics (imbalance, volume, value) *before* insert
3. Updated INSERT query to target correct columns:
   - `imbalance`
   - `spread_pct`
   - `bid_value_10` / `ask_value_10`
   - `bid_volume_10` / `ask_volume_10`

**Verification**:
Verified using `test_db_insert.py` and confirmed live data flow with `desktop_app.py`.

### Database Connection Issues

Increase connection pool:
```python
# In database.py
self.pool = psycopg2.pool.ThreadedConnectionPool(
    minconn=5,
    maxconn=20  # Increase from default
)
```

### Slow Queries

Ensure indexes are created:
```sql
-- Check existing indexes
\d orderbook_snapshots

-- Recreate if missing
CREATE INDEX idx_ob_symbol_time ON orderbook_snapshots(symbol, timestamp DESC);
```

---

## Files

- `database_orderbook_schema.sql` - Database schema
- `orderbook_storage.py` - Storage manager implementation
- `ORDERBOOK_STORAGE.md` - This documentation

Ready to deploy! 🚀
